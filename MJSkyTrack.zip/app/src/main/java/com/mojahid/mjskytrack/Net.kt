package com.mojahid.mjskytrack

import java.net.HttpURLConnection
import java.net.URL

object Net {
    /** GET when body is null/empty, otherwise POST as JSON. Returns the response text. */
    fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "MJSkyTrack/1.0")
        c.setRequestProperty("Accept", "application/json")
        if (!body.isNullOrEmpty()) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
