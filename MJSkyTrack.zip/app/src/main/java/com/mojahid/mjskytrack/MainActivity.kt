package com.mojahid.mjskytrack

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val io = Executors.newCachedThreadPool()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {
        /** Network calls run natively so the page never hits CORS limits. */
        @JavascriptInterface
        fun http(id: Int, url: String, body: String) {
            io.execute {
                val text = try { Net.request(url, body) } catch (e: Exception) { "" }
                val b64 = Base64.encodeToString(text.toByteArray(), Base64.NO_WRAP)
                runOnUiThread { web.evaluateJavascript("window.onNative($id,'$b64')", null) }
            }
        }

        @JavascriptInterface
        fun follow(hex: String, name: String) {
            val i = Intent(this@MainActivity, FollowService::class.java)
                .putExtra("hex", hex).putExtra("name", name)
            startForegroundService(i)
        }

        @JavascriptInterface
        fun unfollow() {
            stopService(Intent(this@MainActivity, FollowService::class.java))
        }

        @JavascriptInterface
        fun battery() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }
    }
}
