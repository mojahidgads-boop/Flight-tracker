package com.mojahid.mjskytrack

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class FollowService : Service() {

    private data class Dest(val codes: String, val lat: Double, val lon: Double)

    @Volatile private var gen = 0
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val hex = intent?.getStringExtra("hex") ?: return START_NOT_STICKY
        val name = intent.getStringExtra("name") ?: hex

        makeChannel()
        val first = build("$name", "Connecting...", true)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ID, first)
        }

        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mjskytrack:follow").apply {
                acquire(12 * 60 * 60 * 1000L)
            }
        }

        val myGen = ++gen
        Thread { loop(hex, name, myGen) }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        gen++
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        super.onDestroy()
    }

    private fun loop(hex: String, name: String, myGen: Int) {
        var dest: Dest? = null
        var routeTried = false
        var misses = 0
        var wasAirborne = false

        while (myGen == gen) {
            try {
                val ac = fetchAc(hex)
                if (ac == null) {
                    misses++
                    if (misses >= 8) { finish(name, "Signal lost"); return }
                } else {
                    misses = 0
                    val lat = ac.optDouble("lat", Double.NaN)
                    val lon = ac.optDouble("lon", Double.NaN)
                    val altRaw = ac.opt("alt_baro")
                    val ground = altRaw == "ground"
                    val ft = (altRaw as? Number)?.toInt() ?: 0
                    val gs = ac.optDouble("gs", 0.0)
                    if (ft > 1000) wasAirborne = true

                    if (!routeTried && !lat.isNaN()) {
                        routeTried = true
                        val cs = ac.optString("flight", "").trim()
                        if (cs.isNotEmpty()) dest = fetchRoute(cs, lat, lon)
                    }

                    if (ground && wasAirborne) {
                        finish(name, "Landed" + (dest?.let { " - ${it.codes}" } ?: ""))
                        return
                    }

                    val title = dest?.codes?.takeIf { it.isNotEmpty() }
                        ?.let { "$name  ${it.replace("-", " > ")}" }
                        ?: "$name  destination unknown"
                    val sb = StringBuilder()
                    sb.append(String.format(Locale.US, "%,d ft  %d kt", ft, gs.toInt()))
                    val d = dest
                    if (d != null && !d.lat.isNaN() && !lat.isNaN() && !lon.isNaN()) {
                        val km = haversine(lat, lon, d.lat, d.lon)
                        sb.append(String.format(Locale.US, "  %,d km to go", km.toInt()))
                        if (gs > 60) {
                            val mins = (km / (gs * 1.852) * 60).toInt()
                            sb.append("  ETA ${mins / 60}h ${mins % 60}m")
                        }
                    }
                    notify(build(title, sb.toString(), true))
                }
            } catch (e: Exception) {
                // network hiccup: keep trying
            }
            try { Thread.sleep(15000) } catch (e: InterruptedException) { return }
        }
    }

    private fun fetchAc(hex: String): JSONObject? {
        val t = Net.request("https://api.adsb.lol/v2/hex/$hex", null)
        val arr = JSONObject(t).optJSONArray("ac") ?: return null
        return if (arr.length() > 0) arr.getJSONObject(0) else null
    }

    private fun fetchRoute(callsign: String, lat: Double, lon: Double): Dest? {
        return try {
            val body = JSONObject().put(
                "planes",
                JSONArray().put(
                    JSONObject().put("callsign", callsign).put("lat", lat).put("lng", lon)
                )
            ).toString()
            val t = Net.request("https://api.adsb.lol/api/0/routeset", body)
            val o = JSONArray(t).optJSONObject(0) ?: return null
            var codes = o.optString("_airport_codes_iata", "")
            if (codes.isEmpty() || codes.equals("unknown", true)) codes = ""
            val aps = o.optJSONArray("_airports")
            val last = aps?.optJSONObject(aps.length() - 1)
            if (codes.isEmpty() && last == null) return null
            Dest(
                codes,
                last?.optDouble("lat", Double.NaN) ?: Double.NaN,
                last?.optDouble("lon", Double.NaN) ?: Double.NaN
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun haversine(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(c - a)
        val dLon = Math.toRadians(d - b)
        val x = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(a)) * cos(Math.toRadians(c)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(sqrt(x))
    }

    private fun finish(name: String, msg: String) {
        stopForeground(STOP_FOREGROUND_DETACH)
        notify(build(name, msg, false))
        stopSelf()
    }

    private fun makeChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Flight follow", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notify(n: Notification) {
        getSystemService(NotificationManager::class.java).notify(ID, n)
    }

    private fun build(title: String, text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FollowService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_plane)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
        if (ongoing) b.addAction(Notification.Action.Builder(null, "Stop", stop).build())
        return b.build()
    }

    companion object {
        const val CH = "follow"
        const val ID = 1
        const val ACTION_STOP = "com.mojahid.mjskytrack.STOP"
    }
}
